// index.js — AUREX v1.0.3 (full Termux-ready)
// Node.js + Baileys
'use strict';

const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

// ===== CONFIG =====
const AUREX_NAME = 'AUREX❤️';
const ADMIN_NUMBER = '+6283869651799'; // ubah sesuai admin
const ADMIN_JID = ADMIN_NUMBER.includes('@') ? ADMIN_NUMBER : `${ADMIN_NUMBER}@s.whatsapp.net`;
const DATA_DIR = path.resolve(__dirname, 'data');
const AI_SCRIPT = path.join(__dirname, 'ai_query.py'); // python AI script
const PY_VENV = '/data/data/com.termux/files/usr/bin/python3'; // path python Termux
const AI_FLAG_FILE = path.join(DATA_DIR, 'ai_enabled.flag');
const DEFAULT_AI_ENABLED = true;
const AI_VERSION = 'Yi-6B-chat-8bit'; // contoh versi AI

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// ===== Files =====
const USERS_FILE = path.join(DATA_DIR, 'users.json');
const HISTORY_FILE = path.join(DATA_DIR, 'history.json');
const LEADER_FILE = path.join(DATA_DIR, 'leaderboard.json');

// ===== Helpers: file =====
function ensureFile(filePath, def) {
  if (!fs.existsSync(filePath)) fs.writeFileSync(filePath, JSON.stringify(def, null, 2));
}
ensureFile(USERS_FILE, {});
ensureFile(HISTORY_FILE, {});
ensureFile(LEADER_FILE, {});

function loadJson(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    if (!raw || raw.trim() === '') return {};
    return JSON.parse(raw);
  } catch (e) {
    console.error(`Gagal baca ${filePath}:`, e.message);
    return {};
  }
}

function saveJson(filePath, data) {
  try {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
  } catch (e) {
    console.error(`Gagal simpan ${filePath}:`, e.message);
  }
}

// ===== Data runtime =====
let users = loadJson(USERS_FILE);
let history = loadJson(HISTORY_FILE);
let leaderboard = loadJson(LEADER_FILE);
let awaitingProfile = {}; // { jid: true }

// ===== Utilities =====
function fmtRp(n) { return 'Rp' + Number(n).toLocaleString('id-ID'); }
function thankYouMessage(name, amount) {
  const amt = Number(amount);
  if (amt >= 50000) return `🔥 ${name}, luar biasa! Terima kasih telah traktir ${fmtRp(amt)} — kamu juara!`;
  if (amt >= 20000) return `✨ Thank you ${name}, ${fmtRp(amt)} sangat membantu pengembangan AUREX.`;
  if (amt >= 5000) return `🎉 Mantap ${name}! Traktir ${fmtRp(amt)} — makasih banyak!`;
  const small = [
    `Sip ${name}, terima kasih traktirnya ${fmtRp(amt)} 😄`,
    `Wah mantep, ${name}! ${fmtRp(amt)} — makasih!`,
    `Thanks ${name}! Kopi dulu ya ☕ ${fmtRp(amt)}`
  ];
  return small[Math.floor(Math.random() * small.length)];
}

// ===== Weekly reset leaderboard =====
function scheduleWeeklyReset() {
  setInterval(() => {
    const now = new Date();
    if (now.getDay() === 1 && now.getHours() === 0 && now.getMinutes() === 0) {
      try {
        const backupFile = path.join(DATA_DIR, `leaderboard-backup-${Date.now()}.json`);
        fs.copyFileSync(LEADER_FILE, backupFile);
        for (const k of Object.keys(leaderboard)) leaderboard[k] = 0;
        saveJson(LEADER_FILE, leaderboard);
        console.log(`${AUREX_NAME}: Leaderboard reset & backup -> ${backupFile}`);
      } catch (e) { console.error('Error saat reset leaderboard:', e); }
    }
  }, 60 * 1000);
}
scheduleWeeklyReset();

function getTop10Public() {
  const entries = Object.entries(leaderboard || {}).sort((a,b) => b[1]-a[1]).slice(0,10);
  if (!entries.length) return 'Belum ada traktir minggu ini.';
  let out = '🏆 TOP 10 Traktir Minggu Ini 🏆\n';
  entries.forEach(([jid, amt], idx) => {
    const name = users[jid]?.name || jid.split('@')[0];
    out += `${idx+1}. ${name} — ${fmtRp(amt)}\n`;
  });
  return out;
}

function getTop10Admin() {
  const entries = Object.entries(leaderboard || {}).sort((a,b) => b[1]-a[1]).slice(0,10);
  if (!entries.length) return 'Belum ada traktir minggu ini.';
  let out = '📊 DETAIL TOP 10 (admin view)\n';
  entries.forEach(([jid, amt], idx) => {
    const name = users[jid]?.name || jid.split('@')[0];
    out += `${idx+1}. ${name} (${jid}) — ${fmtRp(amt)}\n`;
  });
  return out;
}

// ===== AI helper =====
async function askAI(prompt, timeoutMs = 30000) {
  return new Promise((resolve) => {
    if (!fs.existsSync(AI_SCRIPT)) {
      return resolve(`AUREX: (AI offline) Saya menerima: "${prompt}"`);
    }

    // AI flag
    let aiEnabled = DEFAULT_AI_ENABLED;
    try { aiEnabled = !!JSON.parse(fs.readFileSync(AI_FLAG_FILE,'utf8')).enabled; } catch(e){}
    if (!aiEnabled) return resolve('AUREX: AI saat ini nonaktif.');

    try {
      const py = spawn(PY_VENV, [AI_SCRIPT], { cwd: __dirname, env: process.env, stdio:['pipe','pipe','pipe'] });
      let out = '', err = '', responded = false;

      const timer = setTimeout(() => {
        if (!responded) { try { py.kill(); } catch(e){}; responded=true; resolve('AUREX: AI tidak merespon (timeout).'); }
      }, timeoutMs);

      py.stdout.on('data', d => out += d.toString());
      py.stderr.on('data', d => { err += d.toString(); console.error('AI STDERR:', d.toString()); });

      py.on('close', code => {
        if (responded) return;
        responded = true;
        clearTimeout(timer);

        const o = out.trim();
        if (!o) {
          if (err.trim()) return resolve(`AUREX (AI error): ${err.split('\n').slice(0,4).join(' ')}`);
          return resolve('AUREX: AI tidak memberikan output.');
        }

        try {
          const json = JSON.parse(o);
          if (json && typeof json.text === 'string') return resolve(json.text);
          return resolve(String(o));
        } catch(e){ return resolve(String(o)); }
      });

      py.stdin.write(prompt+'\n');
      py.stdin.end();

    } catch(e){ resolve(`AUREX: Error menjalankan AI: ${e.message}`); }
  });
}

// ====== Start Aurex (Baileys) =====
async function startAurex() {
  try {
    const { state, saveCreds } = await useMultiFileAuthState(path.join(__dirname,'auth'));
    const sock = makeWASocket({ auth: state, browser:['AUREX','Chrome','1.0'] });
    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', (update) => {
      const { qr, connection, lastDisconnect } = update;
      if (qr) { console.log('📲 Scan QR:'); qrcode.generate(qr,{small:true}); }
      if (connection==='open') console.log(`${AUREX_NAME} connected ✅`);
      if (connection==='close') {
        console.log(`${AUREX_NAME}: closed, reconnecting...`);
        setTimeout(()=>startAurex().catch(console.error),2000);
        if (lastDisconnect) console.log('lastDisconnect:', lastDisconnect.error?.output||lastDisconnect.error||'unknown');
      }
    });

    sock.ev.on('messages.upsert', async (m) => {
      try {
        const msg = m.messages && m.messages[0]; if(!msg||!msg.message) return;
        const senderJid = msg.key.remoteJid; if(!senderJid) return;
        if(senderJid.endsWith('@g.us')) return;

        const text = (msg.message.conversation ||
                     msg.message.extendedTextMessage?.text ||
                     msg.message.imageMessage?.caption ||
                     msg.message.videoMessage?.caption || '').trim();
        if(!text) return;

        if(!users[senderJid]) { users[senderJid]={name:null,banned:false,totalAmount:0}; saveJson(USERS_FILE,users); }
        if(!history[senderJid]) history[senderJid]=[];
        history[senderJid].push({time:Date.now(),text}); saveJson(HISTORY_FILE,history);

        if(users[senderJid].banned){ await sock.sendMessage(senderJid,{text:'⚠️ Maaf, akun diblokir.'}); return; }

        if(awaitingProfile[senderJid]) {
          const profileText = text;
          const nameLine = profileText.split('\n')[0].trim();
          users[senderJid].name = nameLine || (`User${senderJid.split('@')[0].slice(-4)}`);
          awaitingProfile[senderJid] = false; saveJson(USERS_FILE,users);
          await sock.sendMessage(senderJid,{text:`✅ Data tersimpan: *${users[senderJid].name}*.`});
          return;
        }

        // Commands
        if(text.startsWith('/')) {
          const parts = text.split(' ').filter(Boolean);
          const cmd = parts[0].toLowerCase();
          const args = parts.slice(1);

          // ===== USER COMMANDS =====
          if(cmd === '/startai') {
            if(!users[senderJid].name){ awaitingProfile[senderJid]=true; await sock.sendMessage(senderJid,{text:'👋 Halo! Ketik nama/data kamu:'}); return; }
            await sock.sendMessage(senderJid,{text:`${AUREX_NAME} siap membantu, *${users[senderJid].name}*.`}); return;
          }

          if(cmd === '/help') {
            const txt=`📖 *Bantuan AUREX*\n\n/startai → Mulai AI\n/history → Riwayat chat\n/traktir [jumlah] → Traktir\n/leaderboard → TOP 10\n/aiinfo → Info AI\n/help → Bantuan\n📞 Admin: https://wa.me/${ADMIN_NUMBER}`;
            await sock.sendMessage(senderJid, { text: txt });
return;
          }

          if(cmd === '/history') {
            if(args[0]==='admin' && senderJid===ADMIN_JID) {
              await sock.sendMessage(senderJid,{text:JSON.stringify(history,null,2).slice(0,6000)});
            } else if(args[0]==='user' && args[1] && senderJid===ADMIN_JID) {
              const target=args[1], logs=history[target]||[];
              await sock.sendMessage(senderJid,{text:`📜 History ${target}:\n${logs.map(h=>`${new Date(h.time).toLocaleString()}: ${h.text}`).join('\n')||'Kosong'}`});
            } else {
              const myLogs=history[senderJid]||[];
              const out=myLogs.slice(-50).map(h=>`- ${new Date(h.time).toLocaleString()}: ${h.text}`).join('\n')||'Belum ada history.';
              await sock.sendMessage(senderJid,{text:`🗂 Riwayat Chat (max 50):\n${out}`});
            }
            return;
          }

          if(cmd === '/traktir') {
            const val=args[0]?Number(String(args[0]).replace(/[^0-9]/g,'')):0;
            if(!val||isNaN(val)||val<=0){ await sock.sendMessage(senderJid,{text:'⚠️ Format: /traktir [jumlah]'}); return; }
            users[senderJid].totalAmount=(users[senderJid].totalAmount||0)+val;
            leaderboard[senderJid]=(leaderboard[senderJid]||0)+val;
            saveJson(USERS_FILE,users); saveJson(LEADER_FILE,leaderboard);
            const name=users[senderJid].name||senderJid.split('@')[0];
            const thank=thankYouMessage(name,val);
            await sock.sendMessage(senderJid,{text:`🙏 ${thank}\nTotal kamu: ${fmtRp(users[senderJid].totalAmount)}`});
            return;
          }

          if(cmd === '/leaderboard') {
            if(args[0]==='admin' && senderJid===ADMIN_JID){ await sock.sendMessage(senderJid,{text:getTop10Admin()}); }
            else{ await sock.sendMessage(senderJid,{text:getTop10Public()}); }
            return;
          }

          if(cmd === '/aiinfo') {
            const flag=fs.existsSync(AI_FLAG_FILE)?!!JSON.parse(fs.readFileSync(AI_FLAG_FILE,'utf8')).enabled:DEFAULT_AI_ENABLED;
            await sock.sendMessage(senderJid,{text:`🤖 AI Version: ${AI_VERSION}\nStatus: ${flag?'AKTIF':'NONAKTIF'}\nScript: ${AI_SCRIPT}\nPython: ${PY_VENV}`});
            return;
          }

          // ===== ADMIN COMMANDS =====
          if(senderJid===ADMIN_JID){
            if(cmd==='/datauser'){ await sock.sendMessage(senderJid,{text:JSON.stringify(users,null,2).slice(0,6000)}); return; }
            if(cmd==='/banneduser' && args[0]){ const t=args[0]; if(users[t]){ users[t].banned=true; saveJson(USERS_FILE,users); await sock.sendMessage(senderJid,{text:`🚫 User ${t} dibanned.`}); } else await sock.sendMessage(senderJid,{text:`User ${t} tidak ditemukan.`}); return; }
            if(cmd==='/unban' && args[0]){ const t=args[0]; if(users[t]){ users[t].banned=false; saveJson(USERS_FILE,users); await sock.sendMessage(senderJid,{text:`✅ User ${t} di-unban.`}); } else await sock.sendMessage(senderJid,{text:`User ${t} tidak ditemukan.`}); return; }
            if(cmd==='/onai'||cmd==='/offai'){ const enable=cmd==='/onai'; fs.writeFileSync(AI_FLAG_FILE,JSON.stringify({enabled:enable})); await sock.sendMessage(senderJid,{text:`🤖 AI sekarang: ${enable?'AKTIF':'NONAKTIF'}`}); return; }
            if(cmd==='/pkuu' && args[0] && args[1]){ const tgt=args[0], pesan=args.slice(1).join(' '); try{ await sock.sendMessage(tgt,{text:`📩 Pesan khusus Admin:\n${pesan}`}); await sock.sendMessage(senderJid,{text:`✅ Pesan terkirim ke ${tgt}`}); } catch(e){ await sock.sendMessage(senderJid,{text:`❌ Gagal kirim ke ${tgt}: ${e.message}`}); } return; }
            if(cmd==='/resetleaderboard'){ for(const k of Object.keys(leaderboard)) leaderboard[k]=0; saveJson(LEADER_FILE,leaderboard); await sock.sendMessage(senderJid,{text:'🔁 Leaderboard di-reset oleh admin.'}); return; }
          }

          // Unknown command
          await sock.sendMessage(senderJid,{text:'⚠️ Command tidak dikenali. Ketik /help untuk daftar perintah.'});
          return;
        }

        // ===== Non-command: AI reply =====
        let aiFlag = DEFAULT_AI_ENABLED;
        if(fs.existsSync(AI_FLAG_FILE)){ try{ aiFlag=!!JSON.parse(fs.readFileSync(AI_FLAG_FILE,'utf8')).enabled; }catch(e){} }
        if(aiFlag){
          const name=users[senderJid].name||senderJid.split('@')[0];
          const prompt=`${name}: ${text}\nAUREX:`;
          const reply=await askAI(prompt);
          await sock.sendMessage(senderJid,{text:reply});
        } else {
          await sock.sendMessage(senderJid,{text:'🤖 AUREX sedang nonaktif. Ketik /help untuk info.'});
        }

      } catch(err){ console.error('ERROR handling message:', err && (err.stack||err.message||err)); }
    });

    console.log(`${AUREX_NAME} starting...`);
  } catch(e){ console.error('startAurex error:', e); }
}

startAurex().catch(console.error);
