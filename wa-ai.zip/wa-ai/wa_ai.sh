#!/data/data/com.termux/files/usr/bin/bash
# wa_ai.sh — start AI server (optional) and Aurex bot

DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[*] Starting AUREX AI server (background)..."
# jalankan ai_server.py di background (jika kamu punya model dan cukup resource)
nohup python3 "$DIR/ai_server.py" > "$DIR/data/ai_server.log" 2>&1 &

sleep 3
echo "[*] Starting AUREX Node bot..."
cd "$DIR"
node index.js
