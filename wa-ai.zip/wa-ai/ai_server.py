# ai_server.py - persistent ai server (stdin mode)
import sys, threading
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline

MODEL_PATH = "/storage/emulated/0/AI/Yi-6B-chat-8bit"  # sesuaikan
print("AUREX AI server starting...", flush=True)

tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
model = AutoModelForCausalLM.from_pretrained(MODEL_PATH, device_map="auto")
generator = pipeline("text-generation", model=model, tokenizer=tokenizer)

# Read lines from stdin and output result line by line
for line in sys.stdin:
    prompt = line.strip()
    if not prompt:
        print("", flush=True)
        continue
    try:
        out = generator(prompt, max_new_tokens=120, do_sample=True, top_k=50, temperature=0.7)
        text = out[0]["generated_text"]
        # replace newlines with placeholder so Baileys reads one-line reply (optional)
        text = text.replace("\n", " ")
        print(text, flush=True)
    except Exception as e:
        print(f"ERROR: {e}", flush=True)
