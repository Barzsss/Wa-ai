# ai_query.py - simple one-shot runner (loads model each call => lambat)
import sys
from transformers import AutoTokenizer, AutoModelForCausalLM
from transformers import pipeline

MODEL_PATH = "/storage/emulated/0/AI/Yi-6B-chat-8bit"  # sesuaikan
def main():
    if len(sys.argv) < 2:
        print("No prompt")
        return
    prompt = sys.argv[1]
    # if prompt contains spaces, rest are joined too:
    if len(sys.argv) > 2:
        prompt = " ".join(sys.argv[1:])
    # load tokenizer + model
    tokenizer = AutoTokenizer.from_pretrained(MODEL_PATH)
    model = AutoModelForCausalLM.from_pretrained(MODEL_PATH, device_map="auto")
    gen = pipeline("text-generation", model=model, tokenizer=tokenizer)
    out = gen(prompt, max_new_tokens=120, do_sample=True, top_k=50, temperature=0.7)
    print(out[0]["generated_text"])

if __name__ == "__main__":
    main()
